
#ifndef __P_MATRIX__
#define __P_MATRIX__

#include "esUtil.h"

GLfloat* matTranslate(GLfloat x, GLfloat y, GLfloat z)	{
	GLfloat* matrix = new GLfloat[16];

	for (int i = 0; i < 16; i ++)	{
		matrix[i] = 0.0f;
	}

	matrix[12] = x;
	matrix[13] = y;
	matrix[14] = z;

	return matrix;
}

GLfloat* matRotate(GLfloat angle, bool x, bool y, bool z)	{
	GLfloat* matrix = new GLfloat[16];

	for (int i = 0; i < 16; i ++)	{
		matrix[i] = 0;
	}

	if(x)	{
		//matrix[];
	}

	return NULL;
}

GLfloat* mulMatrix4(GLfloat* mat1, GLfloat* mat2)	{
	GLfloat* matrix = new GLfloat[16];

	for (int j = 0; j < 16; j ++)	{
		matrix[j] = 0.0f;
		for (int i = 0; i < 4; i ++)	{
			matrix[j] += mat1[4*((int)(j/4))+i] * mat2[4*i+(j%4)];
		}
	}

	return matrix;
}

#endif