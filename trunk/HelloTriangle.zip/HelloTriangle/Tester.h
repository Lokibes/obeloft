
#ifndef __TESTER__
#define __TESTER__

#include <iostream>
#include <string>
#include <fstream>
#include <list>
#include <stdio.h>
using namespace std;

#include "ObjParser.h"

int testList()	{
	list<int> mylist;
	int myint;

	cout << "Please enter some integers (enter 0 to end):\n";

	do {
		cin >> myint;
		mylist.push_back (myint);
	} while (myint);

	cout << "mylist stores " << (int) mylist.size() << " numbers.\n";
	return 1;
}

int testReadTextFile(char* filename)	{
	FILE* f = fopen(filename, "r");

	char str[100];
	for (int i = 0; i < 100; i ++)	str[i] = '0';
	float ector[60], textcoords[40];

	for (int i = 0; i < 20; i ++)	{
		fgets(str, 100, f);
		printf("%s\n", str);
		if (str[0] == 'v')	{
			sscanf (str,"v %f %f %f", &ector[3*i], &ector[3*i+1], &ector[3*i+2]);
		}

		else	{
			i --;
		}
	}

	printf("Vector :\n");
	for (int i = 0; i < 20; i ++)	{
		printf("%f %f %f\n", ector[3*i], ector[3*i+1], ector[3*i+2]);
	}

	return 0;
}

int testObjParser(char* filename)	{
	Obj3D* obj = new Obj3D;
	obj = parseFile(filename);

	return 1;
}

int myTest()	{
	//return testList();
	//return testReadTextFile("Woman1.obj");
	return testObjParser("Woman1.obj");
}

#endif