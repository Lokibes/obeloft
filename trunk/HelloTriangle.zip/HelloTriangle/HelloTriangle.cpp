
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

#include "Tester.h"
#include "esUtil.h"
#include "load_Shader.h"
#include "ObjParser.h"
#include "TextureLoader.h"
//#include "Texture.h"

extern bool DEBUG;

#define PI 3.14159
#define texSkyBack	"betty_color.tga"
#define model3D		"Woman2.obj"

Obj3D* obj;

GLfloat myProj_Matrix[]	= {	
	1.0f,	0.0f,	0.0f,	0.0f,
	0.0f,	1.0f,	0.0f,	0.0f,
	0.0f,	0.0f,	1.0f,	0.0f,
	0.0f,	0.0f,	0.0f,	1.0f	};

GLfloat myView_Matrix[]	= {	
	1.0f,	0.0f,	0.0f,	0.0f,
	0.0f,	1.0f,	0.0f,	0.0f,
	0.0f,	0.0f,	1.0f,	0.0f,
	0.0f,	-1.0f,	0.0f,	1.0f	};

float angle = PI / 6.0f;
GLfloat myModel_Matrix[]	= {	
	  cos(angle),	0.0f,	sin(angle),	0.0f,
	  0.0f,			1.0f,	0.0f,		0.0f,
	 -sin(angle),	0.0f,	cos(angle),	0.0f,
	  0.0f,			0.0f,	0.0f,		1.0f	};

GLfloat myTranslateY_Matrix[]	= {	
	1.0f,	0.0f,	0.0f,	0.0f,
	0.0f,	1.0f,	0.0f,	0.0f,
	0.0f,	0.0f,	1.0f,	0.0f,
	0.0f,	0.1f,	0.0f,	1.0f	};

GLfloat myUnits_Matrix[]	= {	
	1.0f,	0.0f,	0.0f,	0.0f,
	0.0f,	1.0f,	0.0f,	0.0f,
	0.0f,	0.0f,	1.0f,	0.0f,
	0.0f,	0.0f,	0.0f,	1.0f	};

GLfloat aColor_rainbow[] = {
	1.0f, 0.0f, 0.0f, 1.0f,
	0.0f, 1.0f, 0.0f, 1.0f,
	0.0f, 0.0f, 1.0f, 1.0f	};

GLfloat aColor_red[] = {
	1.0f, 0.0f, 0.0f, 1.0f,
	1.0f, 0.0f, 0.0f, 1.0f,
	1.0f, 0.0f, 0.0f, 1.0f	};

GLfloat aColor_blur_green[] = { 
	0.0f, 1.0f, 0.0f, 0.4f,
	0.0f, 1.0f, 0.0f, 0.4f,	//	"Alpha" can be enabled with a blending function
	0.0f, 1.0f, 0.0f, 0.4f	};

GLfloat vVertices_red[] = {  
	 0.0f,  0.5f, -0.5f, //triangle red
	-0.5f, -0.5f, -0.5f,
	 0.5f, -0.5f, -0.5f	};

GLfloat vVertices_blur_green1[] = { 
	0.0f, 0.5f, -0.5f, //rectangle overlap the triangle, with the same Z
	-1.0f, 0.5f, -0.5f,
	-1.0f, 0.0f, -0.5f	};

GLfloat vVertices_blur_green2[] = { 
	-1.0f, 0.0f, -0.5f,
	0.0f, 0.0f, -0.5f,
	0.0f, 0.5f, -0.5f,	};

GLfloat* M = myModel_Matrix;
GLfloat* V = myView_Matrix;
GLfloat* P = myProj_Matrix;

typedef struct	{
   // Handle to a program object
   GLuint programObject;
   GLuint iVerticesLoc;
   GLuint iColorLoc;
   GLuint iVerticesLoc1;
   GLuint iColorLoc1;
} UserData;

// Create a shader object, load the shader source, and compile the shader.
GLuint LoadShader ( GLenum type, const char *shaderSrc )
{
   GLuint shader;
   GLint compiled;
   
   // Create the shader object
   shader = glCreateShader ( type );

   if ( shader == 0 )
   	return 0;

   // Load the shader source
   glShaderSource ( shader, 1, &shaderSrc, NULL );
   
   // Compile the shader
   glCompileShader ( shader );

   // Check the compile status
   glGetShaderiv ( shader, GL_COMPILE_STATUS, &compiled );

   if ( !compiled ) 
   {
      GLint infoLen = 0;

      glGetShaderiv ( shader, GL_INFO_LOG_LENGTH, &infoLen );
      
      if ( infoLen > 1 )
      {
         char* infoLog = (char*)malloc (sizeof(char) * infoLen );

         glGetShaderInfoLog ( shader, infoLen, NULL, infoLog );
         esLogMessage ( "Error compiling shader:\n%s\n", infoLog );            
         
         free ( infoLog );
      }

      glDeleteShader ( shader );
      return 0;
   }

   return shader;

}

void LoadTexture ()	{
	//	Generating texture
	Texture* tex = loadTexture(texSkyBack, loadTGA);
	glGenTextures(1, &(tex->texID));

	//	Binding and loading
	glBindTexture(GL_TEXTURE_2D, tex->texID);
	glTexImage2D(GL_TEXTURE_2D, 0, tex->texType, tex->width, tex->height, 0, tex->texType, GL_UNSIGNED_BYTE, tex->imageData);

	printTexInfo(tex);

	//	Setting parameters
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_REPEAT);
}

// Initialize the shader and program object
int Init ( ESContext *esContext )	{
	UserData *userData = (UserData *)esContext->userData;
	char * vShaderStr = ReadFile("./vshader.glsl");
	char * fShaderStr = ReadFile("./fshader.glsl");

	obj = parseFile(model3D);

	GLuint vertexShader;
	GLuint fragmentShader;
	GLuint programObject;
	GLint linked;

	// Load the vertex - fragment shaders
	vertexShader = LoadShader ( GL_VERTEX_SHADER, (char*)vShaderStr );
	fragmentShader = LoadShader ( GL_FRAGMENT_SHADER, (char*)fShaderStr );

	// Create the program object
	programObject = glCreateProgram ( );

	if ( programObject == 0 )
		return 0;

	glAttachShader ( programObject, vertexShader );
	glAttachShader ( programObject, fragmentShader );


	// Bind vPosition to attribute 0   
	// glBindAttribLocation ( programObject, iVerticesLoc, "a_position" );

	// Link the program
	glLinkProgram ( programObject );

	// Check the link status
	glGetProgramiv ( programObject, GL_LINK_STATUS, &linked );

	if ( !linked )	{
		GLint infoLen = 0;

		glGetProgramiv ( programObject, GL_INFO_LOG_LENGTH, &infoLen );

		if ( infoLen > 1 )	{
			char* infoLog = (char*)malloc (sizeof(char) * infoLen );

			glGetProgramInfoLog ( programObject, infoLen, NULL, infoLog );
			esLogMessage ( "Error linking program:\n%s\n", infoLog );            

			free ( infoLog );
		}

		glDeleteProgram ( programObject );
		return FALSE;
	}

	// Store the program object
	userData->programObject = programObject;

	glClearColor ( 0.0f, 0.0f, 0.0f, 0.0f );
	return TRUE;
}

// re-implement the gluPerspective() with its parameter-list
GLfloat* myPerspectiveMatrix (GLfloat fovy, GLfloat aspect, GLfloat zNear, GLfloat zFar)	{
	GLfloat f = 1/tan(fovy/2);
	GLfloat matrix[] = {
		f/aspect,		0,		0,								0,
		0,				f,		0,								0,
		0,				0,		(zNear+zFar)/(zNear-zFar),		(2*zNear*zFar)/(zNear-zFar),
		0,				0,		-1,								0	};

	GLfloat* mat = new GLfloat[16];
	for (int i = 0; i < 16; i ++)	mat[i] = matrix[i];

	return mat;
}

// re-implement the gluFrustum() with its parameter-list
GLfloat* myFrustumMatrix (GLfloat left, GLfloat right, GLfloat bottom, GLfloat top, GLfloat Near, GLfloat Far)	{
	GLfloat matrix[] = {
		2*Near/(right-left),		0,							0,							0,
		0,							2*Near/(top-bottom),		0,							0,
		(right+left)/(right-left),	(top+bottom)/(top-bottom),	(Near+Far)/(Near-Far),		(2*Near*Far)/(Near-Far),
		0,							0,							-1,							0	};

	GLfloat* mat = new GLfloat[16];
	for (int i = 0; i < 16; i ++)	mat[i] = matrix[i];

	return mat;
}

GLfloat* mulMatrix4(GLfloat* mat1, GLfloat* mat2)	{
	GLfloat* matrix = new GLfloat[16];

	for (int j = 0; j < 16; j ++)	{
		matrix[j] = 0.0f;
		for (int i = 0; i < 4; i ++)	{
			matrix[j] += mat1[4*((int)(j/4))+i] * mat2[4*i+(j%4)];
		}
	}

	return matrix;
}

void Draw2(ESContext *esContext)	{
	UserData *userData = (UserData *)esContext->userData;
	// Set the viewport
	glViewport ( 0, 0, esContext->width, esContext->height );
	// Use the program object
	glUseProgram ( userData->programObject );

	glClear ( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );	
	
	//draw triangle RED
	userData->iVerticesLoc = glGetAttribLocation ( userData->programObject , "a_position");
	userData->iColorLoc = glGetAttribLocation ( userData->programObject , "a_color");
	
	GLfloat* myFrustum_Matrix = myFrustumMatrix(-2.0f, 2.0f, -2.0f, 2.0f, 0.1f, 1000.0f);

	glUniformMatrix4fv(glGetUniformLocation(userData->programObject, "u_viewMatrix"), 1, GL_FALSE, myView_Matrix);
	glUniformMatrix4fv(glGetUniformLocation(userData->programObject, "u_projMatrix"), 1, GL_FALSE, myFrustum_Matrix);
	glUniformMatrix4fv(glGetUniformLocation(userData->programObject, "u_modelMatrix"), 1, GL_FALSE, myUnits_Matrix);

	glVertexAttribPointer ( userData->iVerticesLoc, 3, GL_FLOAT, GL_FALSE, 0, vVertices_red );
	glVertexAttribPointer ( userData->iColorLoc, 4, GL_FLOAT, GL_FALSE, 0, aColor_rainbow );
	glEnableVertexAttribArray ( userData->iVerticesLoc );
	glEnableVertexAttribArray ( userData->iColorLoc );
	
	glEnable ( GL_BLEND );
	glBlendFunc ( GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA );

	// Draw a 3-color triangle
	glDrawArrays ( GL_TRIANGLES, 0, 3 );

	// Draw 2 triangles to form a rectangle
	glVertexAttribPointer ( userData->iVerticesLoc, 3, GL_FLOAT, GL_FALSE, 0, vVertices_blur_green1 );
	glVertexAttribPointer ( userData->iColorLoc, 4, GL_FLOAT, GL_FALSE, 0, aColor_blur_green );
	//glDrawArrays ( GL_TRIANGLES, 0, 3 );	//	or use
	GLuint indexes[] = {0, 1, 2};
	glDrawElements ( GL_TRIANGLES, 3, GL_UNSIGNED_INT, indexes );

	glVertexAttribPointer ( userData->iVerticesLoc, 3, GL_FLOAT, GL_FALSE, 0, vVertices_blur_green2 );
	glVertexAttribPointer ( userData->iColorLoc, 4, GL_FLOAT, GL_FALSE, 0, aColor_blur_green );
	//glDrawArrays ( GL_TRIANGLES, 0, 3 );	//	or use this, with the same indexes defined above

	glDrawElements ( GL_TRIANGLES, 3, GL_UNSIGNED_INT, indexes );

	// Swap the 2 buffers
	eglSwapBuffers ( esContext->eglDisplay, esContext->eglSurface );
}

// Draw, using the shaders created in Init()
void Draw (ESContext *esContext)	{
	UserData *userData = (UserData*)esContext->userData;
	glViewport (0, 0, esContext->width, esContext->height);
	glUseProgram ( userData->programObject );
	glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);	

	GLfloat texcoords_pos[] = {
		0.5f, 0.0f,
		0.0f, 1.0f,
		1.0f, 0.0f
	};

	//myFrustum_Matrix = myFrustumMatrix(-2.0f, 2.0f, -2.0f, 2.0f, 20.1f, 1000.0f);
	
	glUniformMatrix4fv (glGetUniformLocation(userData->programObject, "u_projMatrix"), 1, GL_FALSE, P);
	glUniformMatrix4fv (glGetUniformLocation(userData->programObject, "u_viewMatrix"), 1, GL_FALSE, V);
	glUniformMatrix4fv (glGetUniformLocation(userData->programObject, "u_modelMatrix"), 1, GL_FALSE, M);

	userData->iVerticesLoc = glGetAttribLocation (userData->programObject , "a_position");
	userData->iColorLoc = glGetAttribLocation (userData->programObject , "a_uv");
	glVertexAttribPointer (userData->iVerticesLoc, 3, GL_FLOAT, GL_FALSE, 0, obj->vertices);
	glVertexAttribPointer (userData->iColorLoc, 2, GL_FLOAT, GL_FALSE, 0, obj->texcoords);

	//	Enable some shit things in order to make it work =.=
	glEnableVertexAttribArray (userData->iVerticesLoc);
	glEnableVertexAttribArray (userData->iColorLoc);

	//glUniform1i(userData->iColorLoc, 0);

	glDrawArrays(GL_TRIANGLES, 0, 3 * obj->size);
	
	eglSwapBuffers (esContext->eglDisplay, esContext->eglSurface);
}

void myKey (ESContext* esContext, unsigned char key, int x, int y)	{
	printf("%c is pressed !\n", key);
	switch (key)	{
	case 'w':
	case 'W':
		myModel_Matrix[7] += 0.1f;
		break;
	case 's':
	case 'S':
		myModel_Matrix[7] -= 0.1f;
		break;
	case 'a':
	case 'A':
		myModel_Matrix[3] -= 0.1f;
		break;
	case 'd':
	case 'D':
		myModel_Matrix[3] += 0.1f;
		break;
	case 'z':
		myModel_Matrix[11] -= 0.1f;
		break;
	case 'Z':
		myModel_Matrix[11] += 0.1f;
		break;
	case 'y':
	case 'Y':
		P = mulMatrix4(P, myModel_Matrix);
		break;
	}
}

int realMain()	{
	ESContext esContext;
	UserData  userData;

	esInitContext ( &esContext );
	esContext.userData = &userData;

	esCreateWindow ( &esContext, "Hello Triangle", 800, 600, ES_WINDOW_RGB );

	if ( !Init ( &esContext ) )	return 0;

	LoadTexture();

	esRegisterDrawFunc ( &esContext, Draw );

	esRegisterKeyFunc ( &esContext, myKey );

	esMainLoop ( &esContext );

	return 1;
}

int main ( int argc, char *argv[] )	{
	return realMain();
	//return myTest();
}
