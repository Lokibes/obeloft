
#ifndef __OBJ_PARSER__
#define __OBJ_PARSER__

#include <Windows.h>
#include <list>
using namespace std;

#include "esUtil.h"

typedef struct	{
	GLfloat* vertices;
	GLfloat* texcoords;
	GLfloat* normalvecs;
	GLuint size;
} Obj3D;

Obj3D* parseFile(char* objname);

#endif