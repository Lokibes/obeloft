
#include "ObjParser.h"

#define MAX_LINE_LENGTH		60

Obj3D* parseFile(char* objname)	{
	list<GLfloat> vList;
	
	char str[MAX_LINE_LENGTH];
	for (int i = 0; i < MAX_LINE_LENGTH; i ++)	str[i] = '0';
	GLuint size = 0;
	GLfloat vx = 0.0f, vy = 0.0f, vz = 0.0f;
	GLfloat* vers, * texs, * nvecs;

	FILE* f = fopen(objname, "r");

	//	First loop : to retrieve all 3D vertice-coordinates
	while (true)	{
		fgets(str, MAX_LINE_LENGTH, f);

		if (str[0] == 'v')	{
			sscanf(str, "v %f %f %f", &vx, &vy, &vz);
			vList.push_back(vx);
			vList.push_back(vy);
			vList.push_back(vz);

			size ++;
		}

		else if (str[0] == '#' && size != 0)	{				//	End of vertices block
			printf("End of vertices block\n");
			vers = new GLfloat[3 * size];		//	!NOTE : right here vList.size() = 3 * size

			for (int i = 0; i < 3 * size; i ++)	{
				vers[i] = vList.front();
				vList.pop_front();
			}
			
			vList.clear();	//	To ensure that the vers can be re-used without harm
			size = 0;

			break;
		}
	}

	//	Second loop : to retrieve all normal vectors
	while (true)	{
		fgets(str, MAX_LINE_LENGTH, f);

		if (str[0] == 'v')	{
			sscanf(str, "vn %f %f %f", &vx, &vy, &vz);
			vList.push_back(vx);
			vList.push_back(vy);
			vList.push_back(vz);

			size ++;
		}

		else if (str[0] == '#')	{	//	End of normalized vectors block
			printf("End of normalized vectors block\n");
			nvecs = new GLfloat[3 * size];

			for (int i = 0; i < 3 * size; i ++)	{
				nvecs[i] = vList.front();
				vList.pop_front();
			}

			vList.clear();
			size = 0;

			break;
		}
	}

	//	Third loop : to retrieve all texture coordinates
	while (true)	{
		fgets(str, MAX_LINE_LENGTH, f);

		if (str[0] == 'v')	{
			sscanf(str, "vt %f %f", &vx, &vy);
			vList.push_back(vx);
			vList.push_back(vy);

			size ++;
		}

		else if (str[0] == '#')	{	//	End of vertex-textures block
			printf("End of textures block\n");
			texs = new GLfloat[2 * size];

			for (int i = 0; i < 2 * size; i ++)	{
				texs[i] = vList.front();
				vList.pop_front();
			}

			vList.clear();
			size = 0;

			break;
		}
	}

	//	Forth loop : to re-arrange data of all the faces-with-texture
	GLuint v1 = 0, v2 = 0, v3 = 0, n1 = 0, n2 = 0, n3 = 0, t1 = 0, t2 = 0, t3 = 0;
	list<GLfloat> nList, tList;
	Obj3D* myobj = new Obj3D;	//	The leading actor finally arrived :))
	while (true)	{
		fgets(str, MAX_LINE_LENGTH, f);

		if (str[0] == 'f')	{
			sscanf(str, "f %i/%i/%i %i/%i/%i %i/%i/%i", &v1, &t1, &n1, &v2, &t2, &n2, &v3, &t3, &n3);
			vList.push_back(vers[3*(v1-1)]);	vList.push_back(vers[3*(v1-1)+1]);	vList.push_back(vers[3*(v1-1)+2]);
			vList.push_back(vers[3*(v2-1)]);	vList.push_back(vers[3*(v2-1)+1]);	vList.push_back(vers[3*(v2-1)+2]);
			vList.push_back(vers[3*(v3-1)]);	vList.push_back(vers[3*(v3-1)+1]);	vList.push_back(vers[3*(v3-1)+2]);

			nList.push_back(nvecs[3*(n1-1)]);	nList.push_back(nvecs[3*(n1-1)+1]);	nList.push_back(nvecs[3*(n1-1)+2]);
			nList.push_back(nvecs[3*(n2-1)]);	nList.push_back(nvecs[3*(n2-1)+1]);	nList.push_back(nvecs[3*(n2-1)+2]);
			nList.push_back(nvecs[3*(n3-1)]);	nList.push_back(nvecs[3*(n3-1)+1]);	nList.push_back(nvecs[3*(n3-1)+2]);

			tList.push_back(texs[2*(t1-1)]);	tList.push_back(texs[2*(t1-1)+1]);
			tList.push_back(texs[2*(t2-1)]);	tList.push_back(texs[2*(t2-1)+1]);
			tList.push_back(texs[2*(t3-1)]);	tList.push_back(texs[2*(t3-1)+1]);

			size ++;
		}

		else if (str[0] == '#')	{	//	End of defined-faces block
			printf("End of defined-faces block\n");
			myobj->vertices = new GLfloat[9 * vList.size()];
			myobj->normalvecs = new GLfloat[9 * nList.size()];
			myobj->texcoords = new GLfloat[6 * tList.size()];

			for (int i = 0; i < 3 * size; i ++)	{
				myobj->vertices[3*i] = vList.front();		vList.pop_front();
				myobj->vertices[3*i+1] = vList.front();		vList.pop_front();
				myobj->vertices[3*i+2] = vList.front() - 12.5f;		vList.pop_front();

				myobj->normalvecs[3*i] = nList.front();		nList.pop_front();
				myobj->normalvecs[3*i+1] = nList.front();	nList.pop_front();
				myobj->normalvecs[3*i+2] = nList.front();	nList.pop_front();

				GLfloat tx = tList.front();		tList.pop_front();
				GLfloat ty = tList.front();		tList.pop_front();

				myobj->texcoords[2*i] = tx;
				myobj->texcoords[2*i+1] = ty;
				
				/*myobj->texcoords[2*i] = tList.front() + 0.5;		tList.pop_front();
				myobj->texcoords[2*i+1] = tList.front() + 0.5;		tList.pop_front();*/
			}

			vList.clear();
			nList.clear();
			tList.clear();

			myobj->size = size;

			break;
		}
	}

	fclose(f);

	FILE* result = fopen("result.txt", "w");

	fprintf(result, "VERTICES\n");
	for (int i = 0; i < 3 * size; i ++)	{
		fprintf(result, "\t%f\t%f\t%f\n", myobj->vertices[3*i], myobj->vertices[3*i+1], myobj->vertices[3*i+2]);
	}

	fprintf(result, "NORMAL-VECS\n");
	for (int i = 0; i < 3 * size; i ++)	{
		fprintf(result, "\t%f\t%f\t%f\n", myobj->normalvecs[3*i], myobj->normalvecs[3*i+1], myobj->normalvecs[3*i+2]);
	}

	fprintf(result, "TEX-COORDS\n");
	for (int i = 0; i < 3 * size; i ++)	{
		fprintf(result, "\t%f\t%f\n", myobj->texcoords[2*i], myobj->texcoords[2*i+1]);
	}
	
	fclose(result);

	return myobj;
}